package me.capcom.smsgateway.data.entities

data class MessagesStats(
    val count: Int,
    val lastTimestamp: Long
)