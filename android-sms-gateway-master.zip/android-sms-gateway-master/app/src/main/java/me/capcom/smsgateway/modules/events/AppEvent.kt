package me.capcom.smsgateway.modules.events

open class AppEvent(
    @Transient
    val name: String,
)